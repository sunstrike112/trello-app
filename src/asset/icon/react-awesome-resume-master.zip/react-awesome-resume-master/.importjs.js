module.exports = {
  importDevDependencies: true,
}
