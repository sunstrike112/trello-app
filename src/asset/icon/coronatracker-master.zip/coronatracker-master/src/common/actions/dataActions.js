export const getDataFromAPI=()=>{
    
}