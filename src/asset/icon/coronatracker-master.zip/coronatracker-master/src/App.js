import React from 'react';
import './App.css';
import Combine from './common/container/Combine';

function App() {
  return (
    <div className="App">
     <Combine/>
    </div>
  );
}

export default App;
